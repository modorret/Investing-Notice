
document.getElementById('searchInput').addEventListener('input',e=>{
const q=e.target.value.toLowerCase();
document.querySelectorAll('.card').forEach(c=>{
c.style.display=c.textContent.toLowerCase().includes(q)?'block':'none';
});
});
